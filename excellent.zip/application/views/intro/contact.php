<?php
	$this->load->view('templates/header');
?>
<!--聯絡我們-->
<?php
	$this->load->view('templates/footer');
?>