<?php
  $this->load->view('templates/header');
?>
<!--成果專區-->  
<div class="inner">
	
</div>
<?php
	$this->load->view('templates/footer');
?>