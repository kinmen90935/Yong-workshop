
<div class="inner">
	<div class="col span_7_of_12">
	    <p style="border-bottom-style:solid; border-width:medium; color:#4A67FF;">
	      <a class="link" href="<?php echo base_url();?>admin/home">後台首頁</a>>
	    </p>
	</div>
</div>
<!-- inner -->

