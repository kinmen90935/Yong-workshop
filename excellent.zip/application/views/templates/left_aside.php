
	<div class="col span_2_of_12">
	    <p style="border-bottom-style:solid; border-width:medium; color:#4A67FF;">
	      預留aside
	    </p>
	</div>