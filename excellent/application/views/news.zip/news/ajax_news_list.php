<table>
	<?php foreach ($news_list as $key => $news) { ?>
		html    <?=$news['id']; ?>
	<?php } ?> 
</table>
11